import React, {Component} from 'react';

class Index extends Component {
    render() {
        return (
            <div>
                index index
            </div>
        );
    }
}

export default Index;
