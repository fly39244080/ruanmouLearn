import React from 'react';
import {Icon, Layout} from 'antd';

const {Header} = Layout;

class MyHeader extends React.Component {
    constructor() {
        super()
        this.state = {
            collapsed: false,
        };
    }

    toggle = () => {
        this.setState({
            collapsed: !this.state.collapsed,
        });
    };

    render() {
        return (
            <Header style={{background: '#fff', padding: 0, paddingLeft: '24px'}}>
                <Icon
                    className="trigger"
                    type={this.props.collapsed ? 'menu-unfold' : 'menu-fold'}
                    onClick={this.props.toggle}
                />
            </Header>
        );
    }
}

export default MyHeader