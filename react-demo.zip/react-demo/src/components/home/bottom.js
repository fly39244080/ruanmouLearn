import React from 'react';
import {Icon, Layout} from 'antd';

const {Footer} = Layout;

class MyHeader extends React.Component {
    render() {
        return (
            <Footer>
                菲拉斯kdj富翁放开了kljdf
            </Footer>
        );
    }
}

export default MyHeader