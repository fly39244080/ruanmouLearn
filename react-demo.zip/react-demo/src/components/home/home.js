import React from 'react';
import {Icon, Layout, Menu} from 'antd';
import {Link} from 'react-router-dom'
import MyHeader from './header'
import Main from './main'
import Bottom from './bottom'
import {allMenu} from '../menu'

const {SubMenu} = Menu;
const {Sider} = Layout;

class Home extends React.Component {
    constructor() {
        super()
        this.state = {
            collapsed: false,
        };
    }

    toggle = () => {
        this.setState({
            collapsed: !this.state.collapsed,
        });
    };

    // toggle() {
    //     this.setState({
    //         collapsed: !this.state.collapsed,
    //     });
    // };

    render() {
        return (
            <Layout>
                <Sider trigger={null} collapsible collapsed={this.state.collapsed}>
                    <div className="logo"/>
                    <Menu theme="dark" mode="inline" defaultSelectedKeys={['index']}>
                        {
                            allMenu.map(v => {
                                if (v.children && v.children.length > 0) {
                                    return (
                                        <SubMenu
                                            key={v.url}
                                            title={
                                                <span>
                                          <Icon type={v.icon}/>
                                          <span>{v.name}</span>
                                        </span>
                                            }
                                        >
                                            {
                                                v.children.map(o => {
                                                    return (
                                                        <Menu.Item key={o.url}> <Link to={'/' + o.url}>{o.name}</Link></Menu.Item>
                                                    )
                                                })
                                            }
                                        </SubMenu>
                                    )
                                } else {
                                    return (
                                        <Menu.Item key={v.url}>
                                            <Link to={'/' + v.url}>
                                                <Icon type={v.icon}/>
                                                <span>{v.name}</span>
                                            </Link>
                                        </Menu.Item>
                                    )
                                }
                            })
                        }
                    </Menu>

                </Sider>
                <Layout>
                    <MyHeader toggle={this.toggle} collapsed={this.state.collapsed}></MyHeader>
                    {/*<MyHeader toggle={this.toggle} collapsed={this.state.collapsed}></MyHeader>*/}
                    <Main></Main>
                    <Bottom/>
                </Layout>
            </Layout>
        );
    }
}

export default Home