import React from 'react';
import {Layout} from 'antd';
import {Route} from 'react-router-dom'

import Dashboard from '../dashboard/dashboard'
import Music from '../music/music'

const {Content} = Layout;

class Main extends React.Component {

    render() {
        return (
            <Content
                style={{
                    margin: '24px 16px',
                    padding: 24,
                    background: '#fff',
                    minHeight: 280,
                }}
            >
                <Route path="/dashboard" component={Dashboard}></Route>
                <Route path="/music" component={Music}></Route>
            </Content>
        );
    }
}

export default Main