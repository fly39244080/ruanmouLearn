import React, {Component} from 'react'
import {BrowserRouter as Router, Route, Redirect, Link} from 'react-router-dom'
import login from './login/login'
import home from './home/home'
import 'antd/dist/antd.css'

class Routes extends Component {
    render() {
        return (
            <Router>
               {/* <div>
                    <li><Link to='/login'>login</Link></li>
                    <li><Link to='/home'>home</Link></li>
                </div>*/}
                <div>
                    <Route path="/login" component={login}></Route>
                    <Route path="/home" component={home}></Route>
                    <Redirect exact from="/" to="/login"/>
                </div>
            </Router>
        )
    }

}

export default Routes