import React, {Component} from 'react';

class Music extends Component {
    render() {
        return (
            <div className="App">
                MusicMusicMusic
            </div>
        );
    }
}

export default Music;
