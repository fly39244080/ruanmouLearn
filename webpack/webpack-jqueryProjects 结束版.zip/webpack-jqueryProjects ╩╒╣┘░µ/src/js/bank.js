import 'styles/bank.less';
// import $ from 'jquery';

// import '../images/bank/ABC.jpg';
import aa from 'images/bank/ABC.jpg';
console.log(aa);
console.log(config);
console.log(sceneParam);

console.log(process.env.NODE_ENV);

// console.log($);
// console.log(jQuery);

$('#bankList').on('click',function(){
    alert('bbb');
})

// var test = function(){
//     return new Promise(function(resolve,reject){
//         setTimeout(()=>{
//             resolve('oo');
//         },1000)
//     })
// }

// test();